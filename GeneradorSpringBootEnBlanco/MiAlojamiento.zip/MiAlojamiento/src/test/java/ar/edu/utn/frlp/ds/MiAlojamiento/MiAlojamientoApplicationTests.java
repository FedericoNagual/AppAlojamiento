package ar.edu.utn.frlp.ds.MiAlojamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiAlojamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
